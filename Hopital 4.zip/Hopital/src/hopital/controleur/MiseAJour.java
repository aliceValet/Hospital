/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.controleur;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.Format;
import hopital.modele.*;

/**
 *
 * @author alicevalet
 */
public class MiseAJour extends JFrame implements ActionListener {

    //declaration des variables
    public Container cp;
    public Scanner keyboard;
    private Connection connect;
    private Statement stmt;
    private ResultSet rset;
    private ResultSetMetaData rsetMeta;

    public JFrame error;
    public JFrame intermediaire;
    public JLabel action;
    public JLabel table;
    public JPanel pan;
    public JPanel pan2;
    public JPanel pan3;
    public JPanel pan4;
    public JPanel pan5;
    public JPanel pan6;
    public JPanel pan7;
    public JPanel pan8;
    public NumberFormat telo;
    public JRadioButton ajout = new JRadioButton("Ajouter");
    public JRadioButton modif = new JRadioButton("Modifier");
    public JRadioButton suppr = new JRadioButton("Supprimer");
    public JRadioButton patient = new JRadioButton("Patient");
    public JRadioButton docteur = new JRadioButton("Docteur");
    public JRadioButton infirmier = new JRadioButton("Infirmier");
    public JRadioButton name = new JRadioButton("Nom");
    public JRadioButton prename = new JRadioButton("Prenom");
    public JRadioButton tele = new JRadioButton("Telephone");
    public JRadioButton addr = new JRadioButton("Adresse");
    public JRadioButton mutu = new JRadioButton("Mutuelle");
    public JRadioButton spec = new JRadioButton("Specialite");
    public JRadioButton cardio = new JRadioButton("CAR");
    public JRadioButton rea = new JRadioButton("REA");
    public JRadioButton chir = new JRadioButton("CHG");
    public ButtonGroup gp = new ButtonGroup();
    public JTextField jtf1 = new JTextField();
    public JTextField jtf2 = new JTextField();
    public JTextField jtf3 = new JTextField();
    public JTextField jtf4 = new JTextField();
    public JTextField jtf5 = new JTextField();
    public JTextField jtf6 = new JTextField();
    public JTextField jtf7 = new JTextField();
    public JTextField jtf8 = new JTextField();
    public JLabel num;
    public JLabel prenom;
    public JLabel nom;
    public JLabel telephon;
    public JLabel ads;
    public JLabel mutuelle;
    public JLabel specialite;
    public JLabel rotation;
    public JLabel salaire;
    public JLabel service;
    public JLabel sentence;
    public JLabel sentence2;
    public JLabel errone;
    public JButton submit;

    private malade ill;
    private docteur doc;

    /*String number;
    String surname;
    String name;
    String tel;
    String address;
    String insurance;*/
    //Constructeur par defaut
    public MiseAJour() {
        this.setTitle("Mise a jour");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cp = getContentPane();
        cp.setBackground(Color.white);
        cp.setLayout(new BorderLayout());
        pan = new JPanel();
        action = new JLabel("Quelle action souhaitez-vous realiser?");
        ajout.addActionListener(this);
        modif.addActionListener(this);
        suppr.addActionListener(this);
        pan2 = new JPanel();
        table = new JLabel("Sur quel acteur voulez-vous la realiser?");
        pan3 = new JPanel();
        submit = new JButton("Poursuivre");
        patient.addActionListener(this);
        docteur.addActionListener(this);
        infirmier.addActionListener(this);
        submit.addActionListener(this);
        pan.add(action);
        pan.add(ajout);
        pan.add(modif);
        pan.add(suppr);
        pan2.add(table);
        pan2.add(patient);
        pan2.add(docteur);
        pan2.add(infirmier);
        pan3.add(submit);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        this.setVisible(true);
    }

    //Pour formater les saisies dans les formulaires d'ajout de donnees
    public abstract class NumberFormat extends Format {

    }

    //procedure graphique pour ajouter un patient (sous forme de formulaire a remplir
    public void AjoutPatient() {

        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        mutuelle = new JLabel("Mutuelle");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(mutuelle);
        pan6.add(jtf6);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        this.setVisible(true);

    }

    //Formulaire graphique pour ajouter un docteur : on devra l'ajouter a la fois a la table employe et la table docteur
    public void AjoutDocteur() {
        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        specialite = new JLabel("Specialite");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(specialite);
        pan6.add(jtf6);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        this.setVisible(true);

    }
    public void AjoutInfirmier(int number, String spec) {
        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        service = new JLabel("Service");
        rotation = new JLabel("Rotation");
        salaire = new JLabel("Salaire");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();
        pan7 = new JPanel();
        pan8 = new JPanel();
        
        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(service);
        pan6.add(jtf6);
        pan7.add(rotation);
        pan7.add(jtf7);
        pan8.add(salaire);
        pan8.add(jtf8);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);
        cp.add(pan7);
        cp.add(pan8);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        jtf7.addActionListener(this);
        jtf8.addActionListener(this);
        this.setVisible(true);

    }

    //Formulaire pour supprimer un patient
    public void SupprPatient() {
        cp.repaint();
        num = new JLabel("Numero du patient");
        submit = new JButton("Supprimer");

        pan.add(num);
        pan.add(jtf1);
        pan2.add(submit);
        cp.add(pan);
        cp.add(pan2);

        jtf1.addActionListener(this);
        submit.addActionListener(this);
        this.setVisible(true);
    }

    public void SupprDocteur(int number) {
        cp.repaint();
        num = new JLabel("Numero du docteur");

        pan.add(num);
        pan.add(jtf1);
        cp.add(pan);

        jtf1.addActionListener(this);
        this.setVisible(true);

    }

    public void ModifPatient() {
        cp.repaint();
        sentence = new JLabel("Quel patient voulez-vous modifier?");
        num = new JLabel("Numero du patient a modifier : ");
        sentence2 = new JLabel("Quelle information voulez-vous modifier?");
        name = new JRadioButton("Nom");
        prename = new JRadioButton("Prenom");
        tele = new JRadioButton("Telephone");
        addr = new JRadioButton("Adresse");
        mutu = new JRadioButton("Mutuelle");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        name.addActionListener(this);
        prename.addActionListener(this);
        tele.addActionListener(this);
        addr.addActionListener(this);
        mutu.addActionListener(this);
        
        gp.add(name);
        gp.add(prename);
        gp.add(tele);
        gp.add(addr);
        gp.add(mutu);
        
        pan.add(sentence);
        pan2.add(num);
        pan2.add(jtf1);
        pan3.add(sentence2);
        pan4.add(name);
        pan4.add(prename);
        pan4.add(tele);
        pan5.add(addr);
        pan5.add(mutu);

        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);

        this.setVisible(true);

    }

    public void ModifDocteur() {
        cp.repaint();
        sentence = new JLabel("Quel patient voulez-vous modifier?");
        num = new JLabel("Numero du patient a modifier : ");
        sentence2 = new JLabel("Quelle information voulez-vous modifier?");
        name = new JRadioButton("Nom");
        prename = new JRadioButton("Prenom");
        tele = new JRadioButton("Telephone");
        addr = new JRadioButton("Adresse");
        spec = new JRadioButton("Specialite");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();
        
        name.addActionListener(this);
        prename.addActionListener(this);
        tele.addActionListener(this);
        addr.addActionListener(this);
        spec.addActionListener(this);
        
        gp.add(name);
        gp.add(prename);
        gp.add(tele);
        gp.add(addr);
        gp.add(spec);
        
        pan.add(sentence);
        pan2.add(num);
        pan2.add(jtf1);
        pan3.add(sentence2);
        pan4.add(name);
        pan4.add(prename);
        pan4.add(tele);
        pan5.add(addr);
        pan5.add(spec);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);

        this.setVisible(true);
    }
    
    public void ModifChambre() {
        cp.repaint();
        sentence = new JLabel("Quel patient voulez-vous changer de service?");
        num = new JLabel("Numero du patient a modifier : ");
        sentence2 = new JLabel("Dans quel service voulez-vous l'affecter?");
        cardio = new JRadioButton("CAR");
        rea = new JRadioButton("REA");
        chir = new JRadioButton("CHG");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();
        
        rea.addActionListener(this);
        chir.addActionListener(this);
        cardio.addActionListener(this);
        
        gp.add(cardio);
        gp.add(chir);
        gp.add(rea);
        
        pan.add(sentence);
        pan2.add(num);
        pan2.add(jtf1);
        pan3.add(sentence2);
        pan4.add(name);
        pan4.add(prename);
        pan4.add(tele);
        pan5.add(addr);
        pan5.add(spec);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);

        this.setVisible(true);
    }
    @Override
    public void actionPerformed(ActionEvent e) {
        if ((e.getSource() == ajout) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                if ((e.getSource() == jtf1) && (e.getSource() == jtf2) && (e.getSource() == jtf3) && (e.getSource() == jtf4) && (e.getSource() == jtf5) && (e.getSource() == jtf6)) {
                    //on recupere les informations saisies dans les jtextfield pour les stocker dans un objet de type malade
                    ill = new malade();
                    ill.setNum(jtf1.getText());
                    ill.setSurname(jtf2.getText());
                    ill.setName(jtf3.getText());
                    ill.setTel(jtf4.getText());
                    ill.setAddress(jtf5.getText());
                    ill.setInsurance(jtf6.getText());
                    try {
                        //on ajoute les informations dans la table malade
                        stmt.executeUpdate("INSERT INTO malade (numero,nom,prenom,telephone,adresse,mutuelle) VALUES(ill.getNum(),ill.getSurname(),ill.getName(),ill.getTel(),ill.getAddress(),ill.getInsurance())");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("L'ajout du malade a la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);

                    }
                }
            }
        }
        if ((e.getSource() == ajout) && (e.getSource() == docteur)) {
            if (e.getSource() == submit) {
                if ((e.getSource() == jtf1) && (e.getSource() == jtf2) && (e.getSource() == jtf3) && (e.getSource() == jtf4) && (e.getSource() == jtf5) && (e.getSource() == jtf6)) {
                    //on recupere les informations saisies dans les jtextfield pour les stocker dans un obbjet de type docteur
                    doc = new docteur();
                    doc.setNum(jtf1.getText());
                    doc.setSurname(jtf2.getText());
                    doc.setName(jtf3.getText());
                    doc.setTel(jtf4.getText());
                    doc.setAddress(jtf5.getText());
                    doc.setSpec(jtf6.getText());
                }
                try {
                    //on ajoute le docteur a la fois dans la table employe et dans la table docteur
                    stmt.executeUpdate("INSERT INTO employe (numero,nom,prenom,telephone,adresse) VALUES(doc.getNum(),doc.getSurname(),doc.getName(),doc.getTel(),doc.getAddress())");
                    stmt.executeUpdate("INSERT INTO docteur (numero,specialite) VALUES (doc.getNum(),doc.getSpec())");
                } catch (SQLException ex) {
                    //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                    error = new JFrame();
                    error.setTitle("Erreur!");
                    error.setSize(300, 100);
                    error.setLocationRelativeTo(null);
                    error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    cp.repaint();
                    errone = new JLabel("L'ajout du docteur a la base de donnees a echoue.");
                    cp.add(errone);
                    error.setVisible(true);

                }

            }
        }
        if ((e.getSource() == modif) && (e.getSource() == docteur)) {

            if (e.getSource() == submit) {
                doc = new docteur();
                doc.setNum(jtf1.getText());

                if (e.getSource() == name) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    nom = new JLabel("Saisissez le nouveau nom");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(nom);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    doc.setSurname(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE employe SET nom=doc.getSurname() WHERE numero=doc.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le docteur a echoue.");
                        }
                    }
                }
                if (e.getSource() == prename) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    prenom = new JLabel("Saisissez le nouveau prenom");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(prenom);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    doc.setName(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE employe SET prenom=doc.getName() WHERE numero=doc.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le docteur a echoue.");
                        }
                    }
                }
                if (e.getSource() == tele) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    telephon = new JLabel("Saisissez le nouveau telephone");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(telephon);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    doc.setTel(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE employe SET telephone=doc.getTel() WHERE numero=doc.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le docteur a echoue.");
                        }
                    }
                }
                if (e.getSource() == addr) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    ads = new JLabel("Saisissez la nouvelle adresse");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(ads);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    doc.setAddress(jtf1.getText());

                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE employe SET adresse=doc.getAddress() WHERE numero=doc.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le docteur a echoue.");
                        }
                    }
                }
                if (e.getSource() == spec) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    specialite = new JLabel("Saisissez la nouvelle specialite");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(specialite);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    doc.setSpec(jtf1.getText());

                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE employe SET adresse=doc.getSpec() WHERE numero=doc.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le docteur a echoue.");
                        }
                    }
                }
            }
        }

        if ((e.getSource() == modif) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                ill = new malade();
                ill.setNum(jtf1.getText());

                if (e.getSource() == name) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    nom = new JLabel("Saisissez le nouveau nom");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(nom);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    ill.setSurname(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE malade SET nom=ill.getSurname() WHERE numero=ill.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le malade a echoue.");
                        }
                    }
                }
                if (e.getSource() == prename) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    prenom = new JLabel("Saisissez le nouveau prenom");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(prenom);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    ill.setName(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE malade SET prenom=ill.getName() WHERE numero=ill.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le malade a echoue.");
                        }
                    }
                }
                if (e.getSource() == tele) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    telephon = new JLabel("Saisissez le nouveau telephone");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(telephon);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    ill.setTel(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE malade SET telephone=ill.getTel() WHERE numero=ill.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le malade a echoue.");
                        }
                    }
                }
                if (e.getSource() == addr) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    ads = new JLabel("Saisissez la nouvelle adresse");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(ads);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    ill.setAddress(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE malade SET adresse=ill.getAddress() WHERE numero=ill.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le malade a echoue.");
                        }
                    }
                }
                if (e.getSource() == mutu) {
                    intermediaire = new JFrame();
                    cp.repaint();
                    mutuelle = new JLabel("Saisissez la nouvelle mutuelle");
                    pan = new JPanel();
                    pan2 = new JPanel();
                    pan.add(mutuelle);
                    pan.add(jtf1);
                    cp.add(pan);
                    pan2.add(submit);
                    cp.add(pan2);
                    intermediaire.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    intermediaire.setLocationRelativeTo(null);
                    intermediaire.setVisible(true);
                    ill.setInsurance(jtf1.getText());
                    if (e.getSource() == submit) {
                        try {

                            stmt.executeUpdate("UPDATE malade SET mutuelle=ill.getInsurance() WHERE numero=ill.getNum()");
                        } catch (SQLException ex) {
                            System.out.println("La modification des renseignements sur le malade a echoue.");
                        }
                    }
                }
            }

        }

        if ((e.getSource() == suppr) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                if (e.getSource() == jtf1) {
                    ill = new malade();
                    ill.setNum(jtf1.getText());
                    try {
                        //on supprime les informations dans la table malade
                        stmt.executeUpdate("DELETE FROM malade WHERE numero=ill.getNum()");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("La suppression du malade de la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);

                    }
                }
            }
        }
        if ((e.getSource() == suppr) && (e.getSource() == docteur)) {
            if (e.getSource() == submit) {
                if (e.getSource() == jtf1) {
                    doc = new docteur();
                    doc.setNum(jtf1.getText());
                    try {
                        //on supprime les informations dans la table docteur et la table employe
                        stmt.executeUpdate("DELETE FROM malade WHERE numero=doc.getNum()");
                        stmt.executeUpdate("DELETE FROM employe WHERE numero=doc.getNum()");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("La suppression du malade de la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);
                    }
                }
            }
        }
    }
}
