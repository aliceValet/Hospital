/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.modele;

/**
 *
 * @author alicevalet
 */
public class malade {
    //declaration des variables
    private String numero;
    private String nom;
    private String prenom;
    private String telephone;
    private String adresse;
    private String mutuelle;
    
    //recuperation des arguments de la table malade protegee en mode private par des getters
    public String getNum(){
        return numero;
    }
    public String getSurname(){
        return nom;
    }
    public String getName(){
        return prenom;
    }
    public String getTel(){
        return telephone;
    }
    public String getAddress(){
        return adresse;
    }
    public String getInsurance(){
        return mutuelle;
    }
    
    //setters pour tous les attributs de malade
    public void setNum(String numero){
        this.numero=numero;
    }
    public void setSurname(String nom){
        this.nom=nom;
    }
    public void setName(String prenom){
        this.prenom=prenom;
    }
    public void setTel(String telephone){
        this.telephone=telephone;
    }
    public void setAddress(String adresse){
        this.adresse=adresse;
    }
    public void setInsurance(String mutuelle){
        this.mutuelle=mutuelle;
    }
}
