/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.modele;

/**
 *
 * @author alicevalet
 */
public class docteur extends employe {
    //declaration de la seule variable en plus de celles contenues dans la table employe
    private String specialite;
    
    //getter de la specialite du docteur
    public String getSpec(){
        return specialite;
    }
    
    //setter pour le seul attribut de docteur en plus de ceux de la classe employe dont elle herite
    public void setSpec(String specialite){
        this.specialite=specialite;
    }
    
}
