/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.modele;

/**
 *
 * @author alicevalet
 */
public class infirmier extends employe{
    //declaration des variables
    private String rotation;
    private String code_service;
    private String salaire;
    
    //getters pour recuperer les informations supplementaires concernant les infirmier(e)s
    public String getRotation(){
        return rotation;
    }
    public String getCodeSer(){
        return code_service;
    }
    public String getSalaire(){
        return salaire;
    }
}
