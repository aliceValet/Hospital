/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

import javafx.application.Application;
import javafx.scene.Scene;
import javafx.scene.chart.*;
import javafx.scene.layout.*;
import javafx.stage.Stage;

/**
 *
 * @author Luc
 */
public class Reporting1 extends Application { 
  
    @Override 
    public void start(Stage primaryStage) { 
        // Création du graphique. 
        final PieChart chart = new PieChart(); 
        chart.setTitle("Stock de fruits"); 
        chart.getData().setAll(new PieChart.Data("Pommes", 50), new PieChart.Data("Oranges", 30),  
                new PieChart.Data("Poires", 25), new PieChart.Data("Pêches", 42), 
                new PieChart.Data("Citrons", 5), new PieChart.Data("Kiwis", 19) 
        ); 
        // Montage de l'IU. 
        final StackPane root = new StackPane(); 
        root.getChildren().add(chart); 
        final Scene scene = new Scene(root, 300, 250); 
        primaryStage.setTitle("Test de PieChart"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 
        
    } 
  
    public static void main(String[] args) { 
        launch(args); 
        
    } 
}

