/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package controleur;

import vue.*;
import java.awt.*;
import java.sql.SQLException;
import java.util.logging.Level;
import java.util.logging.Logger;
import javafx.application.Application;
import javafx.stage.Stage;

/**
 *
 * Contrôle l'interrogation de la BDD dans la Fenetre
 *
 * @author segado
 */
public class Controleur extends Application {

    /**
     *
     * une methode principal (main) pour lancer l'application
     *
     * @param s
     */
    public static void main(String[] s) {
        /*Fenetre f = new Fenetre();
        f.setVisible(true);*/
        Acceuil acceuil = new Acceuil();
        acceuil.setVisible(true);
        // launch(s);
    }

    @Override
    public void start(Stage primaryStage) throws Exception {
        NewFXMain fxmain = new NewFXMain();
        fxmain.start(primaryStage);
    }
}
