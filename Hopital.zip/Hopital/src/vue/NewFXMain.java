/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.chart.PieChart;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Luc
 */
public class NewFXMain extends Application {
    
     @Override 
    public void start(Stage primaryStage) { 
        // Création du graphique. 
        final PieChart chart = new PieChart(); 
        chart.setTitle("Diagramme Camembert services des infirmières"); 
        chart.getData().setAll(new PieChart.Data("Cardiologie", 8), new PieChart.Data("Chirurgie", 13),  
                new PieChart.Data("Réanimation", 7) 
        ); 
        // Montage de l'IU. 
        final StackPane root = new StackPane(); 
        root.getChildren().add(chart); 
        final Scene scene = new Scene(root, 600, 500); 
        primaryStage.setTitle("Infirmière par service"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 
    } 
    public static void main(String[] args) { 
        launch(args); 
    } 

    
}
