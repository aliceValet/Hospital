/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import java.util.ArrayList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.chart.AreaChart;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Luc
 */
public class NewFXMain1 extends Application {
    
    @Override 
    public void start(Stage primaryStage) { 
        // Création des séries. 
        final ArrayList<AreaChart.Series> seriesList = new ArrayList<>(); 
        final String[] seriesNames = {"REA", "CHG", "CAR","Capacité maximal"}; 
        final int[] bed = {1, 2, 3,4}; 
        final int[][] allValues = { 
            {7, 3,0 ,0}, 
            {7, 7, 3,2}, 
            {5, 2, 2,0},
            {8,10,2,4},}; 
        for (int seriesIndex = 0; seriesIndex < seriesNames.length; seriesIndex++) { 
            final AreaChart.Series series = new AreaChart.Series<>(); 
            series.setName(seriesNames[seriesIndex]); 
            final int[] values = allValues[seriesIndex]; 
            for (int bedIndex = 0; bedIndex < bed.length; bedIndex++) { 
                final int year = bed[bedIndex]; 
                final double value = values[bedIndex]; 
                final AreaChart.Data data = new AreaChart.Data(year, value); 
                series.getData().add(data); 
            } 
            seriesList.add(series); 
        } 
        // Création du graphique. 
        final NumberAxis xAxis = new NumberAxis(); 
        xAxis.setLabel("Numéro de lits"); 
        xAxis.setAutoRanging(false); 
        xAxis.setLowerBound(bed[0]); 
        xAxis.setUpperBound(bed[bed.length-1]); 
        xAxis.setTickUnit(1); 
        final NumberAxis yAxis = new NumberAxis(); 
        yAxis.setLabel("Hospitalisation"); 
        yAxis.setAutoRanging(true); 
        yAxis.setForceZeroInRange(true); 
        final AreaChart chart = new AreaChart(xAxis, yAxis); 
        chart.setTitle("Répartition des patients par lits"); 
        chart.getData().setAll(seriesList); 
        // Montage de l'IU. 
        final StackPane root = new StackPane(); 
        root.getChildren().add(chart); 
        final Scene scene = new Scene(root, 600, 500); 
        primaryStage.setTitle("Hopital fondé par Godric Gryffondor"); 
        primaryStage.setScene(scene); 
        primaryStage.show(); 
    } 
  
    public static void main(String[] args) { 
        launch(args); 
    } 
}
