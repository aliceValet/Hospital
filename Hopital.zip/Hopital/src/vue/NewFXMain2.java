/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package vue;

import java.awt.List;
import java.util.ArrayList;
import java.util.LinkedList;
import javafx.application.Application;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.scene.Scene;
import javafx.scene.chart.BarChart;
import javafx.scene.chart.CategoryAxis;
import javafx.scene.chart.NumberAxis;
import javafx.scene.control.Button;
import javafx.scene.layout.StackPane;
import javafx.stage.Stage;

/**
 *
 * @author Luc
 */
public class NewFXMain2 extends Application {

    @Override
    public void start(Stage primaryStage) {

        //Création de séries
        final ArrayList<BarChart.Series> seriesList;
        seriesList = new ArrayList<>();
        final String[] categoriesNames = {"REA", "CHG", "CAR"};
        final String[] seriesNames = {"Chambre", "Hospitalisation", "Infirmier"};
        final int[][] allValues = {
            {8, 10, 6},
            {10, 20, 9},
            {7, 13, 8},
            };
        final double minY = 0;
        double maxY = -Double.MAX_VALUE;
        for (int seriesIndex = 0; seriesIndex < seriesNames.length; seriesIndex++) {
            final BarChart.Series series = new BarChart.Series<>();
            series.setName(seriesNames[seriesIndex]);
            final int[] values = allValues[seriesIndex];
            for (int categoryIndex = 0; categoryIndex < categoriesNames.length; categoryIndex++) {
                final int value = values[categoryIndex];
                final String category = categoriesNames[categoryIndex];
                maxY = Math.max(maxY, value);
                final BarChart.Data data = new BarChart.Data(category, value);
                series.getData().add(data);
            }
            seriesList.add(series);
        }
        // Création du graphique. 
        final CategoryAxis xAxis = new CategoryAxis();
        xAxis.getCategories().setAll(categoriesNames);
        xAxis.setLabel("Services");
        final NumberAxis yAxis = new NumberAxis(minY, maxY, 50);
        yAxis.setLabel("Quantité");
        final BarChart chart = new BarChart(xAxis, yAxis);
        chart.setTitle("Histogramme de gestion des patients");
        chart.getData().setAll(seriesList);
        // Montage de l'IU. 
        final StackPane root = new StackPane();
        root.getChildren().add(chart);
        final Scene scene = new Scene(root, 700, 500);
        primaryStage.setTitle("Hopital de Gryffondor");
        primaryStage.setScene(scene);
        primaryStage.show();
    }

    public static void main(String[] args) {
        launch(args);
    }
}
