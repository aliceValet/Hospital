/*
 * To change this template, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital;

/**
 *
 * Contrôle l'interrogation de la BDD dans la Fenetre
 *
 * @author segado
 */
public class Controleur {

    /**
     *
     * une methode principal (main) pour lancer l'application
     *
     * @param s
     */
    public static void main(String[] s) {
        // creation de la fenetre
        Fenetre f = new Fenetre();
    }
}
