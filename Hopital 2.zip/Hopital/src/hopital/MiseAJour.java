/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.Format;

/**
 *
 * @author alicevalet
 */
public class MiseAJour extends JFrame implements ActionListener {

    public Container cp;
    public Scanner keyboard;
    private Connection connect;
    private Statement stmt;
    private ResultSet rset;
    private ResultSetMetaData rsetMeta;
    
    public JFrame error;
    public JLabel action;
    public JLabel table;
    public JPanel pan;
    public JPanel pan2;
    public JPanel pan3;
    public JPanel pan4;
    public JPanel pan5;
    public JPanel pan6;
    public NumberFormat telo;
    public JRadioButton ajout = new JRadioButton("Ajouter");
    public JRadioButton modif = new JRadioButton("Modifier");
    public JRadioButton suppr = new JRadioButton("Supprimer");
    public JRadioButton patient = new JRadioButton("Patient");
    public JRadioButton docteur = new JRadioButton("Docteur");
    public JRadioButton infirmier = new JRadioButton("Infirmier");
    public JTextField jtf1 = new JTextField();
    public JTextField jtf2 = new JTextField();
    public JTextField jtf3 = new JTextField();
    public JTextField jtf4 = new JTextField();
    public JTextField jtf5 = new JTextField();
    public JTextField jtf6 = new JTextField();
    public JLabel num;
    public JLabel prenom;
    public JLabel nom;
    public JLabel telephon;
    public JLabel ads;
    public JLabel mutuelle;
    public JLabel errone;
    public JButton submit;

    String number;
    String surname;
    String name;
    String tel;
    String address;
    String insurance;

    public MiseAJour() {
        this.setTitle("Mise a jour");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cp = getContentPane();
        cp.setBackground(Color.white);
        cp.setLayout(new BorderLayout());
        pan = new JPanel();
        action = new JLabel("Quelle action souhaitez-vous realiser?");
        ajout.addActionListener(this);
        modif.addActionListener(this);
        suppr.addActionListener(this);
        pan2 = new JPanel();
        table = new JLabel("Sur quel acteur voulez-vous la realiser?");
        pan3 = new JPanel();
        submit = new JButton("Poursuivre");
        patient.addActionListener(this);
        docteur.addActionListener(this);
        infirmier.addActionListener(this);
        submit.addActionListener(this);
        pan.add(action);
        pan.add(ajout);
        pan.add(modif);
        pan.add(suppr);
        pan2.add(table);
        pan2.add(patient);
        pan2.add(docteur);
        pan2.add(infirmier);
        pan3.add(submit);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        this.setVisible(true);
    }

    public abstract class NumberFormat extends Format {

    }

    public void AjoutPatient() {

        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        mutuelle = new JLabel("Mutuelle");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(mutuelle);
        pan6.add(jtf6);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        this.setVisible(true);

    }

    public void AjoutDocteur(int number, String spec) {
        try {
            stmt.executeUpdate("INSERT INTO docteur (numero,specialite) VALUES(number,spec)");
        } catch (SQLException ex) {
            System.out.println("L'ajout du docteur a la base de donnees a echoue.");
        }

    }

    public void SupprPatient(int number) {
        try {
            stmt.executeUpdate("DELETE FROM malade WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La suppression du malade de la base de donnees a echoue.");
        }
    }

    public void SupprDocteur(int number) {
        try {
            stmt.executeUpdate("DELETE FROM docteur WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La suppression du docteur de la base de donnees a echoue.");
        }
    }

    public void ModifPatient(int number) {
        try {
            System.out.println("Que voulez-vous modifier dans les informations du patient numero" + number);
            keyboard = new Scanner(System.in);

            stmt.executeUpdate("DELETE FROM malade WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La modification des renseignements sur le malade a echoue.");
        }
    }

    public void ModifDocteur(int number) {
        try {
            System.out.println("Que voulez-vous modifier dans les informations du docteur numero" + number);

            stmt.executeUpdate("DELETE FROM malade WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La modification des renseignements sur le docteur a echoue.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ((e.getSource() == ajout) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                if ((e.getSource() == jtf1) && (e.getSource() == jtf2) && (e.getSource() == jtf3) && (e.getSource() == jtf4) && (e.getSource() == jtf5) && (e.getSource() == jtf6)) {
                    number = jtf1.getText();
                    surname = jtf2.getText();
                    name = jtf3.getText();
                    tel = jtf4.getText();
                    address = jtf5.getText();
                    insurance = jtf6.getText();
                    try {
                        stmt.executeUpdate("INSERT INTO malade (numero,nom,prenom,telephone,adresse,mutuelle) VALUES(number,surname,name,tel,address,insurance)");
                    } catch (SQLException ex) {
                        error=new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300,100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone=new JLabel("L'ajout du malade a la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);
                        
                    }
                }
            }
        }
        if (e.getSource() == modif) {

        }
        if (e.getSource() == suppr) {

        }

    }

}
