/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.modele;

/**
 *
 * @author alicevalet
 */
public class service {
    //declaration des variables
    private String code;
    private String nom;
    private String batiment;
    private String directeur;
    
    //getters pour recuperer les infos de cette nouvelle classe
    public String getCode(){
        return code;
    }
    public String getName(){
        return nom;
    }
    public String getBat(){
        return batiment;
    }
    public String getDirlo(){
        return directeur;
    }
}
