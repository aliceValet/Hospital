/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package hopital.controleur;

import javax.swing.*;
import java.awt.*;
import java.sql.*;
import java.util.Scanner;
import java.util.ArrayList;
import java.util.logging.Level;
import java.util.logging.Logger;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
import java.text.Format;
import hopital.modele.*;

/**
 *
 * @author alicevalet
 */
public class MiseAJour extends JFrame implements ActionListener {

    public Container cp;
    public Scanner keyboard;
    private Connection connect;
    private Statement stmt;
    private ResultSet rset;
    private ResultSetMetaData rsetMeta;

    public JFrame error;
    public JLabel action;
    public JLabel table;
    public JPanel pan;
    public JPanel pan2;
    public JPanel pan3;
    public JPanel pan4;
    public JPanel pan5;
    public JPanel pan6;
    public NumberFormat telo;
    public JRadioButton ajout = new JRadioButton("Ajouter");
    public JRadioButton modif = new JRadioButton("Modifier");
    public JRadioButton suppr = new JRadioButton("Supprimer");
    public JRadioButton patient = new JRadioButton("Patient");
    public JRadioButton docteur = new JRadioButton("Docteur");
    public JRadioButton infirmier = new JRadioButton("Infirmier");
    public JTextField jtf1 = new JTextField();
    public JTextField jtf2 = new JTextField();
    public JTextField jtf3 = new JTextField();
    public JTextField jtf4 = new JTextField();
    public JTextField jtf5 = new JTextField();
    public JTextField jtf6 = new JTextField();
    public JLabel num;
    public JLabel prenom;
    public JLabel nom;
    public JLabel telephon;
    public JLabel ads;
    public JLabel mutuelle;
    public JLabel specialite;
    public JLabel sentence;
    public JLabel errone;
    public JButton submit;

    private malade ill;
    private docteur doc;

    /*String number;
    String surname;
    String name;
    String tel;
    String address;
    String insurance;*/
    public MiseAJour() {
        this.setTitle("Mise a jour");
        this.setLocationRelativeTo(null);
        this.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        cp = getContentPane();
        cp.setBackground(Color.white);
        cp.setLayout(new BorderLayout());
        pan = new JPanel();
        action = new JLabel("Quelle action souhaitez-vous realiser?");
        ajout.addActionListener(this);
        modif.addActionListener(this);
        suppr.addActionListener(this);
        pan2 = new JPanel();
        table = new JLabel("Sur quel acteur voulez-vous la realiser?");
        pan3 = new JPanel();
        submit = new JButton("Poursuivre");
        patient.addActionListener(this);
        docteur.addActionListener(this);
        infirmier.addActionListener(this);
        submit.addActionListener(this);
        pan.add(action);
        pan.add(ajout);
        pan.add(modif);
        pan.add(suppr);
        pan2.add(table);
        pan2.add(patient);
        pan2.add(docteur);
        pan2.add(infirmier);
        pan3.add(submit);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        this.setVisible(true);
    }

    public abstract class NumberFormat extends Format {

    }

    public void AjoutPatient() {

        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        mutuelle = new JLabel("Mutuelle");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(mutuelle);
        pan6.add(jtf6);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        this.setVisible(true);

    }

    public void AjoutDocteur(int number, String spec) {
        cp.repaint();
        num = new JLabel("Numero");
        nom = new JLabel("Nom");
        prenom = new JLabel("Prenom");
        telephon = new JLabel("Telephone");
        ads = new JLabel("Adresse");
        specialite = new JLabel("Specialite");
        pan3 = new JPanel();
        pan4 = new JPanel();
        pan5 = new JPanel();
        pan6 = new JPanel();

        pan.add(num);
        pan.add(jtf1);
        pan2.add(nom);
        pan2.add(jtf2);
        pan3.add(prenom);
        pan3.add(jtf3);
        pan4.add(telephon);
        pan4.add(jtf4);
        pan5.add(ads);
        pan5.add(jtf5);
        pan6.add(specialite);
        pan6.add(jtf6);
        cp.add(pan);
        cp.add(pan2);
        cp.add(pan3);
        cp.add(pan4);
        cp.add(pan5);
        cp.add(pan6);

        jtf1.addActionListener(this);
        jtf2.addActionListener(this);
        jtf3.addActionListener(this);
        jtf4.addActionListener(this);
        jtf5.addActionListener(this);
        jtf6.addActionListener(this);
        this.setVisible(true);

    }

    public void SupprPatient() {
        cp.repaint();
        num = new JLabel("Numero du patient");

        pan.add(num);
        pan.add(jtf1);
        cp.add(pan);

        jtf1.addActionListener(this);
        this.setVisible(true);
    }

    public void SupprDocteur(int number) {
        cp.repaint();
        num = new JLabel("Numero du docteur");

        pan.add(num);
        pan.add(jtf1);
        cp.add(pan);

        jtf1.addActionListener(this);
        this.setVisible(true);

    }

    public void ModifPatient(int number) {
        cp.repaint();
        sentence = new JLabel("Quel patient voulez-vous modifier?");
        
        pan.add(num);
        pan.add(jtf1);
        cp.add(pan);

        jtf1.addActionListener(this);
        this.setVisible(true);
        try {
            System.out.println("Que voulez-vous modifier dans les informations du patient numero" + number);
            keyboard = new Scanner(System.in);

            stmt.executeUpdate("DELETE FROM malade WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La modification des renseignements sur le malade a echoue.");
        }
    }

    public void ModifDocteur(int number) {
        try {
            System.out.println("Que voulez-vous modifier dans les informations du docteur numero" + number);

            stmt.executeUpdate("DELETE FROM malade WHERE numero=number");
        } catch (SQLException ex) {
            System.out.println("La modification des renseignements sur le docteur a echoue.");
        }
    }

    @Override
    public void actionPerformed(ActionEvent e) {
        if ((e.getSource() == ajout) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                if ((e.getSource() == jtf1) && (e.getSource() == jtf2) && (e.getSource() == jtf3) && (e.getSource() == jtf4) && (e.getSource() == jtf5) && (e.getSource() == jtf6)) {
                    //on recupere les informations saisies dans les jtextfield pour les stocker dans un objet de type malade
                    ill = new malade();
                    ill.setNum(jtf1.getText());
                    ill.setSurname(jtf2.getText());
                    ill.setName(jtf3.getText());
                    ill.setTel(jtf4.getText());
                    ill.setAddress(jtf5.getText());
                    ill.setInsurance(jtf6.getText());
                    try {
                        //on ajoute les informations dans la table malade
                        stmt.executeUpdate("INSERT INTO malade (numero,nom,prenom,telephone,adresse,mutuelle) VALUES(ill.getNum(),ill.getSurname(),ill.getName(),ill.getTel(),ill.getAddress(),ill.getInsurance())");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("L'ajout du malade a la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);

                    }
                }
            }
        }
        if ((e.getSource() == ajout) && (e.getSource() == docteur)) {
            if (e.getSource() == submit) {
                if ((e.getSource() == jtf1) && (e.getSource() == jtf2) && (e.getSource() == jtf3) && (e.getSource() == jtf4) && (e.getSource() == jtf5) && (e.getSource() == jtf6)) {
                    //on recupere les informations saisies dans les jtextfield pour les stocker dans un obbjet de type docteur
                    doc = new docteur();
                    doc.setNum(jtf1.getText());
                    doc.setSurname(jtf2.getText());
                    doc.setName(jtf3.getText());
                    doc.setTel(jtf4.getText());
                    doc.setAddress(jtf5.getText());
                    doc.setSpec(jtf6.getText());
                }
                try {
                    //on ajoute le docteur a la fois dans la table employe et dans la table docteur
                    stmt.executeUpdate("INSERT INTO employe (numero,nom,prenom,telephone,adresse) VALUES(doc.getNum(),doc.getSurname(),doc.getName(),doc.getTel(),doc.getAddress())");
                    stmt.executeUpdate("INSERT INTO docteur (numero,specialite) VALUES (doc.getNum(),doc.getSpec())");
                } catch (SQLException ex) {
                    //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                    error = new JFrame();
                    error.setTitle("Erreur!");
                    error.setSize(300, 100);
                    error.setLocationRelativeTo(null);
                    error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                    cp.repaint();
                    errone = new JLabel("L'ajout du docteur a la base de donnees a echoue.");
                    cp.add(errone);
                    error.setVisible(true);

                }

            }
        }
        if (e.getSource() == modif) {

        }
        if ((e.getSource() == suppr) && (e.getSource() == patient)) {
            if (e.getSource() == submit) {
                if (e.getSource() == jtf1) {
                    ill = new malade();
                    ill.setNum(jtf1.getText());
                    try {
                        //on supprime les informations dans la table malade
                        stmt.executeUpdate("DELETE FROM malade WHERE numero=ill.getNum()");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("La suppression du malade de la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);

                    }
                }
            }
        }
        if ((e.getSource() == suppr) && (e.getSource() == docteur)) {
            if (e.getSource() == submit) {
                if (e.getSource() == jtf1) {
                    doc = new docteur();
                    doc.setNum(jtf1.getText());
                    try {
                        //on supprime les informations dans la table docteur et la table employe
                        stmt.executeUpdate("DELETE FROM malade WHERE numero=doc.getNum()");
                        stmt.executeUpdate("DELETE FROM employe WHERE numero=doc.getNum()");
                    } catch (SQLException ex) {
                        //en cas d'echec on ouvre une nouvelle fenetre signalant que la tentative a echoue
                        error = new JFrame();
                        error.setTitle("Erreur!");
                        error.setSize(300, 100);
                        error.setLocationRelativeTo(null);
                        error.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
                        cp.repaint();
                        errone = new JLabel("La suppression du malade de la base de donnees a echoue.");
                        cp.add(errone);
                        error.setVisible(true);
                    }
                }
            }
        }
    }
}
